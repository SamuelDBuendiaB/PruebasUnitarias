package com.example.calculadora2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button suma,resta,div,multi,fibo,fact;
    private TextView resultado;
    private EditText num1,num2;

    Accion info = new Accion();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicio();

        suma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer = info.suma(num1.getText().toString(),num2.getText().toString());
                resultado.setText(answer);
            }
        });
        resta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer = info.resta(num1.getText().toString(),num2.getText().toString());
                resultado.setText(answer);
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer = info.divicion(num1.getText().toString(),num2.getText().toString());
                resultado.setText(answer);
            }
        });
        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer = info.multiplicacion(num1.getText().toString(),num2.getText().toString());
                resultado.setText(answer);
            }
        });

        fibo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer = info.sequencia();
                Intent intent = new Intent(MainActivity.this, Fibonacci.class);
                intent.putExtra("sequencia", answer);
                startActivity(intent);
            }
        });
        fact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String answer = info.factorial(num1.getText().toString());
                resultado.setText(answer);
            }
        });
    }

    private void inicio(){
        suma =findViewById(R.id.suma);
        resta = findViewById(R.id.resta);
        div = findViewById(R.id.div);
        multi = findViewById(R.id.multi);
        resultado= findViewById(R.id.view);
        num1 = findViewById(R.id.ent1);
        num2 = findViewById(R.id.ent2);
        fibo = findViewById(R.id.button5);
        fact = findViewById(R.id.fact);
    }
}